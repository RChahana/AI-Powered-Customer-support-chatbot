/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.chatbot.dao;

import com.chatbot.model.KnowledgeBaseEntry;
import com.chatbot.util.DBConnection; // adjust if you use another utility class

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class KnowledgeBaseDAO {

    /**
     * Try to find a matching answer from the knowledge base.
     * Matching is done using question pattern OR keywords.
     */
    public String findAnswer(String userMessage) {
        String sql = "SELECT * FROM knowledge_base WHERE LOWER(questionPattern) LIKE LOWER(?) OR LOWER(keywords) LIKE LOWER(?) LIMIT 1";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            String pattern = "%" + userMessage.trim() + "%";
            stmt.setString(1, pattern);
            stmt.setString(2, pattern);

            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return rs.getString("response");
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null; // no match found
    }

    /**
     * Optional – fetch all knowledge base entries (for admin or debugging).
     */
    public List<KnowledgeBaseEntry> getAllEntries() {
        List<KnowledgeBaseEntry> entries = new ArrayList<>();
        String sql = "SELECT * FROM knowledge_base";

        try (Connection conn = DBConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                KnowledgeBaseEntry entry = new KnowledgeBaseEntry();
                entry.setId(rs.getInt("id"));
                entry.setCategory(rs.getString("category"));
                entry.setKeywords(rs.getString("keywords"));
                entry.setQuestionPattern(rs.getString("questionPattern"));
                entry.setResponse(rs.getString("response"));
                entries.add(entry);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return entries;
    }

    /**
     * Optional – add new knowledge base entry.
     */
    public void addEntry(KnowledgeBaseEntry entry) {
        String sql = "INSERT INTO knowledge_base (category, keywords, questionPattern, response) VALUES (?, ?, ?, ?)";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, entry.getCategory());
            stmt.setString(2, entry.getKeywords());
            stmt.setString(3, entry.getQuestionPattern());
            stmt.setString(4, entry.getResponse());
            stmt.executeUpdate();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}

