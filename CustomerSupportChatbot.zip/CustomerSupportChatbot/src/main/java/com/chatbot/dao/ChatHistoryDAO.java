/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.chatbot.dao;

import com.chatbot.model.Message;
import com.chatbot.util.DBConnection;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ChatHistoryDAO {
    
    public boolean saveMessage(Message message) {
        String query = "INSERT INTO chat_history (session_id, user_message, bot_response) VALUES (?, ?, ?)";
        
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {
            
            pstmt.setString(1, message.getSessionId());
            pstmt.setString(2, message.getUserMessage());
            pstmt.setString(3, message.getBotResponse());
            
            return pstmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
    
    public List<Message> getChatHistory(String sessionId) {
        List<Message> messages = new ArrayList<>();
        String query = "SELECT * FROM chat_history WHERE session_id = ? ORDER BY timestamp ASC";
        
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {
            
            pstmt.setString(1, sessionId);
            ResultSet rs = pstmt.executeQuery();
            
            while (rs.next()) {
                Message message = new Message();
                message.setId(rs.getInt("id"));
                message.setSessionId(rs.getString("session_id"));
                message.setUserMessage(rs.getString("user_message"));
                message.setBotResponse(rs.getString("bot_response"));
                message.setTimestamp(rs.getTimestamp("timestamp"));
                messages.add(message);
            }
            rs.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return messages;
    }

    public List<Message> getMessagesBySession(String sessionId) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}