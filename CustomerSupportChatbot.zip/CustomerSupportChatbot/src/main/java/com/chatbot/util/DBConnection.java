/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.chatbot.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 * Database Connection Utility Class for PostgreSQL
 * Manages database connections for the chatbot application
 */
public class DBConnection {
    
    // PostgreSQL Database credentials
    private static final String DB_URL = "jdbc:postgresql://localhost:5432/Chatbot_db";
    private static final String DB_USER = "postgres";
    private static final String DB_PASSWORD = "postgres"; // ⚠️ CHANGE THIS!
    
    // Database connection instance
    private static Connection connection = null;
    
    /**
     * Get database connection
     * Creates a new connection if one doesn't exist or is closed
     * @return Connection object
     */
    public static Connection getConnection() {
        try {
            // Check if connection exists and is valid
            if (connection == null || connection.isClosed()) {
                
                // Load PostgreSQL JDBC Driver
                Class.forName("org.postgresql.Driver");
                
                // Create connection
                connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
                
                System.out.println("PostgreSQL Database connected successfully!");
            }
            
        } catch (ClassNotFoundException e) {
            System.err.println("PostgreSQL JDBC Driver not found!");
            System.err.println("Please add postgresql-XX.jar to your project libraries.");
            e.printStackTrace();
            
        } catch (SQLException e) {
            System.err.println("Database connection failed!");
            System.err.println("Please check:");
            System.err.println("  1. PostgreSQL server is running");
            System.err.println("  2. Database 'Chatbot_db' exists");
            System.err.println("  3. Username and password are correct");
            System.err.println("  4. Port 5432 is correct");
            e.printStackTrace();
        }
        
        return connection;
    }
    
    /**
     * Close database connection
     */
    public static void closeConnection() {
        try {
            if (connection != null && !connection.isClosed()) {
                connection.close();
                System.out.println("✓ Database connection closed successfully.");
            }
        } catch (SQLException e) {
            System.err.println("✗ Error closing connection!");
            e.printStackTrace();
        }
    }
    
    /**
     * Test database connection
     * Run this main method to verify connection works
     */
    public static void main(String[] args) {
        System.out.println("=== Testing PostgreSQL Database Connection ===\n");
        
        Connection conn = DBConnection.getConnection();
        
        if (conn != null) {
            System.out.println("\nSUCCESS! Database connection test passed!");
            System.out.println("Your database is ready to use.");
            closeConnection();
        } else {
            System.out.println("\nFAILED! Database connection test failed!");
            System.out.println("Please check the error messages above and fix the issues.");
        }
    }
}
