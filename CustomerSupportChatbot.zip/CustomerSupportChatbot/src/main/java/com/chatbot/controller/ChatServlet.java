/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package com.chatbot.controller;

import com.chatbot.dao.ChatHistoryDAO;
import com.chatbot.dao.KnowledgeBaseDAO; // NEW DAO for knowledge base
import com.chatbot.model.Message;

import java.io.IOException;
import java.io.PrintWriter;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.*;

import org.json.JSONArray;
import org.json.JSONObject;

public class ChatServlet extends HttpServlet {

    private ChatHistoryDAO chatHistoryDAO;
    private KnowledgeBaseDAO knowledgeBaseDAO; // for FAQ/knowledge base answers

    private static final String GEMINI_API_KEY = "AIzaSyAE9wRsWy5uCIJmrc7BT4Yh_T9EbrKgyoE"; // your API key
    private static final String GEMINI_URL
            = "https://generativelanguage.googleapis.com/v1/models/gemini-2.5-flash:generateContent?key=";

    private static final String SUPPORT_PROMPT =
            "You are an AI-powered Customer Support Chatbot for our company. "
            + "Always respond politely, professionally, and in simple, clear language. "
            + "If the user asks something outside knowledge base, generate the best helpful response.";

    @Override
    public void init() throws ServletException {
        chatHistoryDAO = new ChatHistoryDAO();
        knowledgeBaseDAO = new KnowledgeBaseDAO(); // init
        System.out.println("ChatServlet initialized with KB + Gemini fallback.");
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");

        String userMessage = request.getParameter("message");
        HttpSession session = request.getSession();
        String sessionId = session.getId();

        if (userMessage == null || userMessage.trim().isEmpty()) {
            sendJsonResponse(response, "Please enter a message.", false);
            return;
        }

        try {
            // 1. First try Knowledge Base
            String botResponse = knowledgeBaseDAO.findAnswer(userMessage);

            if (botResponse == null || botResponse.trim().isEmpty()) {
                // 2. Fallback → Gemini
                List<Message> history = chatHistoryDAO.getChatHistory(sessionId);
                botResponse = callGeminiAPI(history, userMessage);
            }

            // 3. Save chat
            Message message = new Message(sessionId, userMessage, botResponse);
            chatHistoryDAO.saveMessage(message);

            // 4. Send response
            sendJsonResponse(response, botResponse, true);

        } catch (Exception e) {
            e.printStackTrace();
            sendJsonResponse(response, "⚠️ Error contacting support system: " + e.getMessage(), false);
        }
    }

    private String callGeminiAPI(List<Message> history, String userMessage) throws Exception {
        HttpClient client = HttpClient.newHttpClient();

        // Build conversation
        StringBuilder conversation = new StringBuilder();
        conversation.append(SUPPORT_PROMPT).append("\n\n");

        if (history != null && !history.isEmpty()) {
            for (Message msg : history) {
                conversation.append("User: ").append(msg.getUserMessage()).append("\n");
                conversation.append("Bot: ").append(msg.getBotResponse()).append("\n");
            }
        }
        conversation.append("User: ").append(userMessage).append("\nBot: ");

        // Build JSON payload
        JSONObject payload = new JSONObject();
        JSONArray contentsArray = new JSONArray();
        JSONObject contentObj = new JSONObject();
        JSONArray partsArray = new JSONArray();
        JSONObject partObj = new JSONObject();
        partObj.put("text", conversation.toString());
        partsArray.put(partObj);
        contentObj.put("parts", partsArray);
        contentsArray.put(contentObj);
        payload.put("contents", contentsArray);

        HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create(GEMINI_URL + GEMINI_API_KEY))
                .header("Content-Type", "application/json")
                .POST(HttpRequest.BodyPublishers.ofString(payload.toString()))
                .build();

        HttpResponse<String> apiResponse = client.send(request, HttpResponse.BodyHandlers.ofString());
        System.out.println("Gemini raw response: " + apiResponse.body());

        if (apiResponse.statusCode() != 200) {
            throw new IOException("Gemini API returned status " + apiResponse.statusCode());
        }

        // Parse Gemini response
        JSONObject json = new JSONObject(apiResponse.body());
        JSONArray candidates = json.optJSONArray("candidates");
        if (candidates != null && candidates.length() > 0) {
            JSONObject content = candidates.getJSONObject(0).getJSONObject("content");
            JSONArray parts = content.optJSONArray("parts");
            if (parts != null && parts.length() > 0) {
                String text = parts.getJSONObject(0).optString("text", "");
                if (!text.isEmpty()) {
                    return text.trim();
                }
            }
        }

        return "Sorry, I couldn’t generate a response right now.";
    }

    private void sendJsonResponse(HttpServletResponse response, String message, boolean success)
            throws IOException {
        PrintWriter out = response.getWriter();
        String json = new JSONObject()
                .put("success", success)
                .put("message", message)
                .toString();
        out.print(json);
        out.flush();
    }
}

