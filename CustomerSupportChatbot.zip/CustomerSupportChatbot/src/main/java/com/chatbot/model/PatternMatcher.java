/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.chatbot.model;

import com.chatbot.dao.KnowledgeBaseDAO;
import java.util.List;
import java.util.regex.Pattern;

public class PatternMatcher {
    
    private KnowledgeBaseDAO knowledgeBaseDAO;
    
    public PatternMatcher() {
        this.knowledgeBaseDAO = new KnowledgeBaseDAO();
    }
    
    public String findResponse(String userMessage) {
        String message = userMessage.toLowerCase().trim();
        List<KnowledgeBaseEntry> entries = knowledgeBaseDAO.getAllEntries();
        
        // Try pattern matching
        for (KnowledgeBaseEntry entry : entries) {
            if (matchesPattern(message, entry.getQuestionPattern())) {
                return entry.getResponse();
            }
        }
        
        // Try keyword matching
        int maxScore = 0;
        String bestResponse = null;
        
        for (KnowledgeBaseEntry entry : entries) {
            int score = calculateKeywordScore(message, entry.getKeywords());
            if (score > maxScore) {
                maxScore = score;
                bestResponse = entry.getResponse();
            }
        }
        
        return (maxScore > 0) ? bestResponse : getDefaultResponse();
    }
    
    private boolean matchesPattern(String message, String patternString) {
        try {
            Pattern pattern = Pattern.compile(patternString, Pattern.CASE_INSENSITIVE);
            return pattern.matcher(message).find();
        } catch (Exception e) {
            return false;
        }
    }
    
    private int calculateKeywordScore(String message, String keywords) {
        int score = 0;
        String[] keywordArray = keywords.split(",");
        
        for (String keyword : keywordArray) {
            if (message.contains(keyword.trim().toLowerCase())) {
                score++;
            }
        }
        return score;
    }
    
    private String getDefaultResponse() {
        String[] responses = {
            "I'm not sure I understand. Could you please rephrase?",
            "I don't have information about that. Would you like to speak with a human agent?",
            "Can you provide more details about your question?"
        };
        return responses[(int)(Math.random() * responses.length)];
    }
    // In PatternMatcher.java
    private boolean isAngry(String message) {
        String[] angryWords = {"angry", "furious", "terrible", "worst", "awful", "ridiculous"};
        for (String word : angryWords) {
            if (message.contains(word)) {
                return true;
            }
        }
        return false;
    }
    public static void main(String[] args) {
        PatternMatcher matcher = new PatternMatcher();
        
        String[] testQueries = {
            "Hello!",
            "What are your hours?",
            "I have a problem",
            "How much does it cost?",
            "Thanks!"
        };
        
        System.out.println("=== Testing Pattern Matcher ===\n");
        for (String query : testQueries) {
            System.out.println("User: " + query);
            System.out.println("Bot: " + matcher.findResponse(query));
            System.out.println("---");
        }
    }
}
