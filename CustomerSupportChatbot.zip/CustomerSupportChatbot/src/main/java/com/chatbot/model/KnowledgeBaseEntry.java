/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.chatbot.model;

public class KnowledgeBaseEntry {
    private int id;
    private String category;
    private String keywords;
    private String questionPattern;
    private String response;
    
    public KnowledgeBaseEntry() {}
    
    public KnowledgeBaseEntry(String category, String keywords, String questionPattern, String response) {
        this.category = category;
        this.keywords = keywords;
        this.questionPattern = questionPattern;
        this.response = response;
    }
    
    // Getters and Setters
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    
    public String getCategory() { return category; }
    public void setCategory(String category) { this.category = category; }
    
    public String getKeywords() { return keywords; }
    public void setKeywords(String keywords) { this.keywords = keywords; }
    
    public String getQuestionPattern() { return questionPattern; }
    public void setQuestionPattern(String questionPattern) { this.questionPattern = questionPattern; }
    
    public String getResponse() { return response; }
    public void setResponse(String response) { this.response = response; }
}
