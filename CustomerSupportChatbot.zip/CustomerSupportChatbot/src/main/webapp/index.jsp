<%-- 
    Document   : Index
    Created on : 5 Oct 2025, 1:12:55 pm
    Author     : Chahana
--%>
<%-- 
    Document   : Index
    Author     : Chahana
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>AI Customer Support Chatbot</title>
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
    <div class="app-wrapper">
        <div class="chat-container">
            
            <!-- Header -->
            <div class="chat-header">
                <div class="header-content">
                    <div class="bot-avatar"><i class="fas fa-robot"></i></div>
                    <div class="bot-info">
                        <h1>AI Customer Support Assistant</h1>
                        <p class="status"><span class="status-dot"></span> Online</p>
                    </div>
                </div>
                <div class="header-actions">
                    <button class="icon-btn" id="clearChat"><i class="fas fa-trash-alt"></i></button>
                    <button class="icon-btn" id="toggleTheme"><i class="fas fa-moon"></i></button>
                </div>
            </div>

            <!-- Messages -->
            <div class="chat-messages" id="chatMessages">
                <div class="message bot-message">
                    <div class="message-avatar"><i class="fas fa-robot"></i></div>
                    <div class="message-content">
                        <div class="message-bubble">
                            👋 Hello! I’m your AI assistant.<br>
                            Ask me about: <br>
                            <ul>
                                <li>🕐 Business hours</li>
                                <li>📦 Order status</li>
                                <li>💰 Pricing</li>
                                <li>🔄 Returns</li>
                            </ul>
                        </div>
                        <span class="message-time">Just now</span>
                    </div>
                </div>
            </div>

            <!-- Typing Indicator -->
            <div class="typing-indicator" id="typingIndicator" style="display: none;">
                <div class="message-avatar"><i class="fas fa-robot"></i></div>
                <div class="typing-dots"><span></span><span></span><span></span></div>
            </div>

            <!-- Quick Replies -->
            <div class="quick-replies" id="quickReplies">
                <button class="quick-reply-btn" data-message="Hello">👋 Say Hello</button>
                <button class="quick-reply-btn" data-message="Order Status">📦 Order Status</button>
                <button class="quick-reply-btn" data-message="Cancel Order">❌ Cancel Order</button>
                <button class="quick-reply-btn" data-message="Return Policy">🔄 Return Policy</button>
            </div>

            <!-- Input -->
            <div class="chat-input-container">
                <form id="chatForm" class="chat-input-form">
                    <input type="text" id="userInput" class="chat-input"
                        placeholder="Type your message..." autocomplete="off" required>
                    <button type="submit" class="send-btn" id="sendBtn">
                        <i class="fas fa-paper-plane"></i>
                    </button>
                </form>
                <p class="input-hint">Press Enter to send • Shift+Enter for new line</p>
            </div>
        </div>
    </div>

    <div class="powered-by">⚡ Powered by AI • Built with Java & JSP</div>

    <script src="js/chat.js"></script>
</body>
</html>
