// ==================== CHAT APPLICATION ====================

class ChatBot {
    constructor() {
        this.chatMessages = document.getElementById('chatMessages');
        this.chatForm = document.getElementById('chatForm');
        this.userInput = document.getElementById('userInput');
        this.sendBtn = document.getElementById('sendBtn');
        this.typingIndicator = document.getElementById('typingIndicator');
        this.clearChatBtn = document.getElementById('clearChat');
        this.toggleThemeBtn = document.getElementById('toggleTheme');
        this.quickReplies = document.querySelectorAll('.quick-reply-btn');
        
        this.init();
    }
    
    init() {
        // Event Listeners
        this.chatForm.addEventListener('submit', (e) => this.handleSubmit(e));
        this.clearChatBtn.addEventListener('click', () => this.clearChat());
        this.toggleThemeBtn.addEventListener('click', () => this.toggleTheme());
        
        // Quick Reply Buttons
        this.quickReplies.forEach(btn => {
            btn.addEventListener('click', () => {
                const message = btn.getAttribute('data-message');
                this.userInput.value = message;
                this.handleSubmit(new Event('submit'));
            });
        });
        
        // Enter key to send, Shift+Enter for new line
        this.userInput.addEventListener('keydown', (e) => {
            if (e.key === 'Enter' && !e.shiftKey) {
                e.preventDefault();
                this.chatForm.dispatchEvent(new Event('submit'));
            }
        });
        
        // Load theme preference
        this.loadTheme();
        
        // Auto-focus input
        this.userInput.focus();
    }
    
    async handleSubmit(e) {
        e.preventDefault();
        
        const message = this.userInput.value.trim();
        if (!message) return;
        
        console.log('Sending message:', message);
        
        // Display user message
        this.addMessage(message, 'user');
        
        // Clear input
        this.userInput.value = '';
        this.userInput.focus();
        
        // Disable send button
        this.sendBtn.disabled = true;
        
        // Show typing indicator
        this.showTyping();
        
        // Send to server
        try {
            const response = await this.sendMessageToServer(message);
            console.log('Server response:', response);
            
            // Hide typing indicator
            this.hideTyping();
            
            // Display bot response
            if (response.success) {
                this.addMessage(response.message, 'bot');
            } else {
                this.addMessage('Sorry, something went wrong. Please try again.', 'bot');
                console.error('Server returned error:', response);
            }
        } catch (error) {
            this.hideTyping();
            this.addMessage('Connection error. Please check your internet connection.', 'bot');
            console.error('Error:', error);
        }
        
        // Enable send button
        this.sendBtn.disabled = false;
    }
    
    async sendMessageToServer(message) {
        try {
            // Encode message
            const params = new URLSearchParams();
            params.append('message', message);

            console.log('Sending to backend:', message);

            const response = await fetch('chat', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8'
                },
                body: params.toString()
            });

            console.log('Response status:', response.status);

            if (!response.ok) {
                throw new Error('HTTP error! status: ' + response.status);
            }

            const data = await response.json();
            console.log('Response JSON:', data);
            return data;

        } catch (error) {
            console.error('Error in sendMessageToServer:', error);
            throw error;
        }
    }

    
    addMessage(text, sender) {
        const messageDiv = document.createElement('div');
        messageDiv.className = `message ${sender}-message`;
        
        const avatar = document.createElement('div');
        avatar.className = 'message-avatar';
        avatar.innerHTML = sender === 'bot' 
            ? '<i class="fas fa-robot"></i>' 
            : '<i class="fas fa-user"></i>';
        
        const content = document.createElement('div');
        content.className = 'message-content';
        
        const bubble = document.createElement('div');
        bubble.className = 'message-bubble';
        bubble.innerHTML = this.formatMessage(text);
        
        const time = document.createElement('span');
        time.className = 'message-time';
        time.textContent = this.getCurrentTime();
        
        content.appendChild(bubble);
        content.appendChild(time);
        
        messageDiv.appendChild(avatar);
        messageDiv.appendChild(content);
        
        this.chatMessages.appendChild(messageDiv);
        this.scrollToBottom();
    }
    
    formatMessage(text) {
        // Escape HTML to prevent XSS
        const div = document.createElement('div');
        div.textContent = text;
        text = div.innerHTML;
        
        // Convert line breaks to <br>
        text = text.replace(/\n/g, '<br>');
        
        // Convert URLs to links
        text = text.replace(
            /(https?:\/\/[^\s]+)/g,
            '<a href="$1" target="_blank" rel="noopener noreferrer">$1</a>'
        );
        
        return text;
    }
    
    showTyping() {
        this.typingIndicator.style.display = 'flex';
        this.scrollToBottom();
    }
    
    hideTyping() {
        this.typingIndicator.style.display = 'none';
    }
    
    scrollToBottom() {
        setTimeout(() => {
            this.chatMessages.scrollTop = this.chatMessages.scrollHeight;
        }, 100);
    }
    
    getCurrentTime() {
        const now = new Date();
        const hours = now.getHours().toString().padStart(2, '0');
        const minutes = now.getMinutes().toString().padStart(2, '0');
        return `${hours}:${minutes}`;
    }
    
    clearChat() {
        if (confirm('Are you sure you want to clear the chat history?')) {
            // Keep only the welcome message
            const messages = this.chatMessages.querySelectorAll('.message');
            messages.forEach((msg, index) => {
                if (index > 0) { // Skip first message (welcome)
                    msg.remove();
                }
            });
            
            this.showNotification('Chat cleared successfully!', 'success');
        }
    }
    
    toggleTheme() {
        document.body.classList.toggle('dark-theme');
        
        const isDark = document.body.classList.contains('dark-theme');
        const icon = this.toggleThemeBtn.querySelector('i');
        
        if (isDark) {
            icon.className = 'fas fa-sun';
            localStorage.setItem('theme', 'dark');
        } else {
            icon.className = 'fas fa-moon';
            localStorage.setItem('theme', 'light');
        }
    }
    
    loadTheme() {
        const theme = localStorage.getItem('theme');
        if (theme === 'dark') {
            document.body.classList.add('dark-theme');
            this.toggleThemeBtn.querySelector('i').className = 'fas fa-sun';
        }
    }
    
    showNotification(message, type = 'info') {
        const notification = document.createElement('div');
        notification.textContent = message;
        notification.style.cssText = `
            position: fixed;
            top: 20px;
            right: 20px;
            padding: 15px 25px;
            background: ${type === 'success' ? '#28a745' : '#17a2b8'};
            color: white;
            border-radius: 8px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.15);
            z-index: 10000;
            animation: slideIn 0.3s ease;
        `;
        
        document.body.appendChild(notification);
        
        setTimeout(() => {
            notification.style.animation = 'slideOut 0.3s ease';
            setTimeout(() => notification.remove(), 300);
        }, 3000);
    }
}

// Initialize chatbot when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    console.log('Initializing ChatBot...');
    new ChatBot();
    console.log('ChatBot initialized successfully!');
});

// Add CSS animations for notifications
const style = document.createElement('style');
style.textContent = `
    @keyframes slideIn {
        from {
            transform: translateX(400px);
            opacity: 0;
        }
        to {
            transform: translateX(0);
            opacity: 1;
        }
    }
    
    @keyframes slideOut {
        from {
            transform: translateX(0);
            opacity: 1;
        }
        to {
            transform: translateX(400px);
            opacity: 0;
        }
    }
`;
document.head.appendChild(style);