<%@ page contentType="text/html" pageEncoding="UTF-8"%>
<%@ page import="com.chatbot.util.DBConnection" %>
<%@ page import="java.sql.*" %>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Database Connection Test</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            max-width: 800px;
            margin: 50px auto;
            padding: 20px;
            background: #f0f0f0;
        }
        .container {
            background: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        .success {
            color: green;
            font-weight: bold;
        }
        .error {
            color: red;
            font-weight: bold;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        th, td {
            border: 1px solid #ddd;
            padding: 12px;
            text-align: left;
        }
        th {
            background-color: #4CAF50;
            color: white;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>🤖 Chatbot Database Test Page</h1>
        
        <%
            Connection conn = null;
            Statement stmt = null;
            ResultSet rs = null;
            
            try {
                // Test database connection
                conn = DBConnection.getConnection();
                
                if (conn != null) {
                    out.println("<p class='success'>✓ Database Connection: SUCCESS!</p>");
                    
                    // Query knowledge base
                    stmt = conn.createStatement();
                    String sql = "SELECT category, COUNT(*) as count FROM knowledge_base GROUP BY category";
                    rs = stmt.executeQuery(sql);
                    
                    out.println("<h2>Knowledge Base Statistics:</h2>");
                    out.println("<table>");
                    out.println("<tr><th>Category</th><th>Number of Entries</th></tr>");
                    
                    int totalEntries = 0;
                    while (rs.next()) {
                        String category = rs.getString("category");
                        int count = rs.getInt("count");
                        totalEntries += count;
                        out.println("<tr><td>" + category + "</td><td>" + count + "</td></tr>");
                    }
                    
                    out.println("<tr><th>Total</th><th>" + totalEntries + "</th></tr>");
                    out.println("</table>");
                    
                    out.println("<p style='margin-top: 20px;'>✓ Your database is properly configured and ready to use!</p>");
                    
                } else {
                    out.println("<p class='error'>✗ Database Connection: FAILED!</p>");
                    out.println("<p>Please check your database configuration in DBConnection.java</p>");
                }
                
            } catch (Exception e) {
                out.println("<p class='error'>✗ Error: " + e.getMessage() + "</p>");
                e.printStackTrace();
                
            } finally {
                // Close resources
                try {
                    if (rs != null) rs.close();
                    if (stmt != null) stmt.close();
                    // Don't close connection here as it's managed by DBConnection class
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        %>
        
        <hr>
        <p><a href="index.html">← Back to Home</a></p>
    </div>
</body>
</html>